learn.tree.greedy <- function(data.incl.count)
{
  require("bnlearn", lib.loc="D:/R/R-3.1.2/library")
  eg = empty.graph(colnames(data.incl.count)[-which(colnames(data.incl.count) %in% "Count")], 1)
  for (tar in colnames(data.incl.count)[-which(colnames(data.incl.count) %in% "Count")])
  {
    fields <- colnames(data.incl.count[-which(colnames(data.incl.count) %in% "Count")])
    descendants <- collect.descendants(eg, tar)
    
    if (length(descendants) > 0) candidates <- fields[-which(fields %in% descendants)]
    else candidates <- fields
    
    out <- learn.tbnl.graph.from.counts(data = data.incl.count[,candidates], counts = data.incl.count[,"Count"], target = tar, constraints = list(max.features = 1), eg = eg)
    eg <- out[[2]]
  }
}