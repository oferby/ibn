bn.graph.arcs.2.parents <- function(graph)
{
  for (curr.node in nodes(graph))
  {
    graph$nodes[[curr.node]]$parents <- collect.ancestors(graph, curr.node, direct.only = T)
    graph$nodes[[curr.node]]$children <- collect.descendants(graph, curr.node, direct.only = T)
    graph$nodes[[curr.node]]$nbr <- c(graph$nodes[[curr.node]]$parents, graph$nodes[[curr.node]]$children)
    parents.of.children <- sapply(graph$nodes[[curr.node]]$children, function(x) collect.ancestors(graph, x, direct.only = T))
    graph$nodes[[curr.node]]$mb <- c(graph$nodes[[curr.node]]$nbr, parents.of.children[-which(parents.of.children %in% curr.node)])
  }
  
  return(graph)
}