marg.prob <- function(data, counts = NULL, margin = NULL, MC = 1000)
{

  if(is.null(margin) == T) data.margin <- data else data.margin <- data[,margin]
  if (is.null(dim(data.margin)) == TRUE)
  {
    data.margin <- data.frame(data.margin)
  }
  else
  {
    data.margin <- as.data.frame(data.margin)
  }
  if(is.null(margin) == T)  colnames(data.margin) <- colnames(data) else colnames(data.margin) <- margin

  unique.data.margin <- unique(data.margin)

  if (is.null(counts) == FALSE)
  {
    if (MC > 0)
    {
        response <- rep(0, length(counts))
        data.prob <- counts/sum(counts)
        cumul.data.prob <- cumsum(data.prob)

        count.cumulated.margin <- 0

        xi <- runif(MC, 0, 1)
        for (iter in 1:MC)
        {

          realization.data.idx <- min(which(xi[iter] <= cumul.data.prob))

          response[realization.data.idx] <- response[realization.data.idx] + 1

        }

        observed.data.margin <- data.margin[which(response>0),]

        if (is.null(dim(observed.data.margin)) == TRUE)
        {
          observed.data.margin <- data.frame(observed.data.margin)
        }
        colnames(observed.data.margin) <- colnames(data.margin)
        unique.data.margin <- unique(observed.data.margin)
        #print(unique.data.margin)
        observed.count <- response[response>0]
        count.cumulated.margin <- sapply(X = 1:nrow(unique.data.margin), FUN = function(x) sum(observed.count[rows.in.a1.that.are.in.a2(observed.data.margin, unique.data.margin[x,])]))
        #print(count.cumulated.margin)
    }
    else
    {
      mp <- marg.prob.old(data, counts, margin)
      unique.data.margin <- mp[[1]]
      count.cumulated.margin <- mp[[2]]
    }
  }
  else
    count.cumulated.margin <- NULL
  return(list(unique.data.margin, count.cumulated.margin))
}
