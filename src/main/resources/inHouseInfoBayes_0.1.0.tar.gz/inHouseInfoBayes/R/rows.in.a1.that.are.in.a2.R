rows.in.a1.that.are.in.a2  <- function(a1,a2)
{
  if (is.null(dim(a1)) == FALSE)
  {
    a1.vec <- gsub("[[:space:]]", "", apply(a1, 1, paste0, collapse = "_"))
  }
  else
  {
    a1.vec <- gsub("[[:space:]]", "", paste0(a1, collapse = "_"))
    a1.vec <- as.matrix(strsplit(a1.vec, split = "_")[[1]])
  }
  if (is.null(dim(a2)) == FALSE)
  {
    a2.vec <- gsub("[[:space:]]", "", apply(a2, 1, paste0, collapse = "_"))
  }
  else
  {
    a2.vec <- gsub("[[:space:]]", "", paste0(a2, collapse = "_"))
  }
  

  a1.with.a2.rows <- which(a1.vec %in% a2.vec)
  return(a1.with.a2.rows)
}