fit.bn.parameters.from.counts <- function(bn, data, counts, prob = T)
{
  temp.data <- as.data.frame(apply(data, 2, as.factor))
  fitted <- bn.fit(bn, temp.data)

  tab <- list()
  for (node in nodes(bn))
  {
    print(node)
    margin <- c(node, bn$nodes[[node]]$parents)
    node.marg <- marg.prob(apply(data, 2, as.factor), counts, margin, MC = 0)
    if (length(bn$nodes[[node]]$parents) > 0)
    {
      #     yaano.tab[[node]] <- array(data = node.marg[[2]], dim = sapply(margin, function(x) nrow(marg.prob(data[,x])[[1]])), dimnames = lapply(margin, function(x) marg.prob(data[,x])[[1]][,1]))
      tab[[node]] <- table(node.marg[[1]])


      yurgensen <- which(tab[[node]] > 0)

      tab.node.df <- as.data.frame(tab[[node]])
      nilsen <- tab.node.df[yurgensen, margin]
      for (z in 1:length(nilsen))
      {
        row.in.data <- rows.in.a1.that.are.in.a2(node.marg[[1]], nilsen[z,])
        tab[[node]][yurgensen[z]] <- node.marg[[2]][row.in.data]
      }

    }
    else
    {
      tab[[node]] <- node.marg[[2]]
      a <- marg.prob(apply(data, 2, as.factor), counts, node, MC = 0)
      b <- matrix(fitted[[node]]$prob, ncol = length(a[[2]]), dimnames = list(NULL, c(sapply(a[[1]], function(x) x))))
      tab[[node]] <- b
    }

    #fitted[[node]]$prob <- tab[[node]]
    #bn$nodes[[node]]$prob <- tab[[node]]

    if (prob == T)
    {
      tab[[node]] <- prop.table(tab[[node]], margin = seq(length(margin))[-1])
    }


  }
  for (node in nodes(bn)) {
    if (length(dim(tab[[node]])) == 2)
      tab[[node]] <- tab[[node]][,order(colnames(tab[[node]]))]

    if (length(bn$nodes[[node]]$parents) == 0)
    {
      a <- marg.prob(apply(data, 2, as.factor), counts, node, MC = 0)
      b <- matrix(tab[[node]], ncol = length(a[[2]]), dimnames = list(NULL, c(sapply(a[[1]], function(x) x))[order(a[[1]])]))
      tab[[node]] <- b
    }
  }
  fitted <- custom.fit(bn, tab)
  return(fitted)
}
