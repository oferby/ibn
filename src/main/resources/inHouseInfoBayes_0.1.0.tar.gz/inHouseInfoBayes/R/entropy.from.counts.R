entropy.from.counts <- function(counts)
{
  probs <- counts/sum(counts)
  return(-sum(probs[which(probs>0)]*log2(probs[which(probs>0)])))
}
