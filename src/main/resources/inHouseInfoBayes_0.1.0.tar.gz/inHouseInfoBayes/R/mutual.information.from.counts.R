mutual.information.from.counts <- function(data, counts, target, about = NULL, MC = 0)
{

  unique.data <- marg.prob(data, counts, colnames(data), MC = 0)

  data.4.entropy <- marg.prob(unique.data[[1]], unique.data[[2]], target, MC = 0)
  #colnames(data.4.entropy) <- target

  if (is.null(about) == TRUE)
  {
    print("Mutual information must have two variables (about cannot be null")
    return(NULL)
  }

  conditioned.colnames <- colnames(data[-which(colnames(data) %in% c(about, target))])
  data.4.condentropy <- marg.prob(unique.data[[1]], unique.data[[2]], c(conditioned.colnames, target), MC = 0)

  # if (MC > 0)
  #   {
  #     xi <- matrix(runif(MC*ncol(data), 0, 1), ncol = ncol(data))
  #     colnames(xi) <- colnames(data)
  #   }

  if (MC > 0)
    {
      xi <- runif(MC, 0, 1)
    }

  # H.Y.conditioned.X <- cond.entropy.from.counts(data = data.4.condentropy[[1]], counts = data.4.condentropy[[2]], target = target, MC, xi[,colnames(data.4.condentropy[[1]])])
  # H.Y.conditioned.Z.X <- cond.entropy.from.counts(data = unique.data[[1]], counts = unique.data[[2]], target = target, MC, xi[,colnames(unique.data[[1]])])

  H.Y.conditioned.X <- cond.entropy.from.counts(data = data.4.condentropy[[1]], counts = data.4.condentropy[[2]], target = target, MC, xi)
  H.Y.conditioned.Z.X <- cond.entropy.from.counts(data = unique.data[[1]], counts = unique.data[[2]], target = target, MC, xi)

  MI <- H.Y.conditioned.X - H.Y.conditioned.Z.X
  #print(MI)
  return(MI)


}
