learn.bn.max.infogain <- function(data, counts, constraints = NULL, MC = 0)
{
  require(bnlearn)
  eg = empty.graph(colnames(data), 1)
  MIs <- matrix(nrow = dim(data)[2], ncol = dim(data)[2])
  Boshko <- matrix(nrow = dim(data)[2], ncol = dim(data)[2])
  fields <- colnames(data)
  i<-0
  for (tar in colnames(data))
  {
    i <- i + 1
    print(tar)
    #Boshko[i,] <- unlist(lapply(X = fields, function(var) mutual.information.from.counts(data[,c(tar,var)], counts, var, about = tar)))
    MIs[i,] <- unlist(lapply(X = fields, function(var) mutual.information.from.counts(data[,c(tar,var)], counts, var, about = tar, MC)))
    #MIs[i,] <- rep(0.89, ncol(data))

  }

  var.1 <- NULL
  var.2 <- NULL

  keep.going <- TRUE
  sunto <- MIs
  while ((keep.going == T) && (max(sunto) > -1))
  {

    var.1 <- which.max(apply(sunto, 2, max))
    var.2 <- which.max(sapply(sunto[,var.1], max))

    parents <- collect.ancestors(eg, colnames(data)[var.2], direct.only = TRUE)



    if (keep.going == TRUE)
      {
        descendants <- collect.descendants(eg, colnames(data)[var.2])

        #fields <- colnames(data)[-which(colnames(data) %in% colnames(data)[var.2])]
        if (length(descendants) > 0) candidates <- fields[-c(var.2, which(fields %in% descendants))]
        else candidates <- fields

        if (colnames(data)[var.1] %in% candidates)
        {
          eg$arcs <- rbind(eg$arcs, c(colnames(data)[var.1], colnames(data)[var.2]))
        }
      }

    eg <- set.graph.nodes.by.arcs(eg)
    plot(eg)

    parents <- collect.ancestors(eg, colnames(data)[var.2], direct.only = TRUE)
    if (is.null(constraints$max.parents)) keep.going <- TRUE
    else
    {
      if (length(parents) < constraints$max.parents) keep.going <- TRUE
      else keep.going <- FALSE
    }

    a <- which(sunto[var.2,] >= 0)
    sunto[var.2, a] <- unlist(lapply(X = fields, function(var) mutual.information.from.counts(data[,c(colnames(data)[var.2], parents, var)], counts, var, about = colnames(data)[var.2], MC)))[a]
    sunto[var.2, var.1] <- -1


  }
  return(eg)


}
