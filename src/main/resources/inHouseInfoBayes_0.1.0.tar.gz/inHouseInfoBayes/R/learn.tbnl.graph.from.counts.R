learn.tbnl.graph.from.counts <- function(data, counts, target, constraints = NULL, family = "nuclear", eg = NULL, MC = 0)
{

  print("Preprocessing...")
  unique.data <- marg.prob(data, counts, MC = 0)
  require("bnlearn")
  if (is.null(eg) == T) eg <- empty.graph(colnames(data), 1)

  model <- feature.selection.from.counts(unique.data[[1]], unique.data[[2]], target, constraints, eg, MC)
  assign('features.learned.already', c(features.learned.already, target), envir = .GlobalEnv)

  if (family == "nuclear")
  {
    if (length(model[[1]] > 0))
    {
      nuclear.data <- unique.data[[1]][,model[[1]]]
      for (feature in model[[1]])
      {
        if ((feature %in% features.learned.already) == F)
        {
          model = learn.tbnl.graph.from.counts(nuclear.data, unique.data[[2]], feature, constraints, family, model[[2]], MC)
        }

      }
    }
  }
  else
  {
    for (feature in model[[1]])
    {
      if ((feature %in% features.learned.already) == F)
      {
        model = learn.tbnl.graph.from.counts(unique.data[[1]], unique.data[[2]], feature, constraints, family, model[[2]], MC)
      }
    }
  }
  return(model)
}
