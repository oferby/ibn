feature.selection.from.counts <- function(data, counts, target, constraints, graph = NULL, MC = 0)
{
  require("parallel")
  start.time <- Sys.time()

  features <- NULL
  total.info <- 0

  keep.going <- F
  if(length(-which(colnames(data) %in% target)) > 0)
  {
    keep.going <- T
  }

  if (length(which(colnames(data) %in% target)) == 0)
    {
      print(paste("Feature selection returned NULL since the target was not found in the data. data fields:", colnames(data), sep = " "))
      return(list(features, graph))
    }


  target.marg <- marg.prob(data, counts, target, MC = 0)
  target.entropy <- cond.entropy.from.counts(target.marg[[1]], target.marg[[2]])

  print(paste("Target =", target, "Entropy =", target.entropy, sep = " "))

  descendants <- collect.descendants(graph = graph, node = target, direct.only = F)

  i<-0
  while(keep.going == T)
  {
    i <-i + 1
    relevant.cols <- colnames(data[-which(colnames(data) %in% c(descendants, features, target))])
    if (length(relevant.cols) == 0)
    {
      keep.going <- F
      break
    }
    MIs <- unlist(mclapply(X = relevant.cols, function(var) mutual.information.from.counts(data[,c(features, var, target)], counts, target, about = var, MC)))
    info.gain.max <- max(MIs[which(!is.nan(MIs))])
    feature.max <- relevant.cols[which(MIs == info.gain.max)]


    if (!is.null(constraints$min.info.gain))
      if (info.gain.max/target.entropy < constraints$min.info.gain)
      {
        keep.going <- F
        break
      }

    total.info.temp <- total.info + info.gain.max
    if (!is.null(constraints$max.total.info))
        if (total.info.temp/target.entropy > constraints$max.total.info)
      {
        keep.going <- F
        break
      }

    if (info.gain.max > 0)
    {
      features[i] <- feature.max[1]
      total.info <- total.info + info.gain.max

      print(paste(features[i], paste(round(info.gain.max/target.entropy*100, 2), "%", sep=""), paste("(", round(total.info/target.entropy*100, 2), "%)", sep=""), sep=" "))

      if (!is.null(constraints$max.features))
        if (length(features) >= constraints$max.features) keep.going <- F

      if (!is.null(constraints$max.total.info))
        if (total.info/target.entropy == constraints$max.total.info) keep.going <- F

      if (i == length(colnames(data[-which(colnames(data) %in% target)]))) keep.going <- F


      if (is.null(graph) == F)
      {

        #       b <- matrix(nrow = length(features), ncol = 2)
        #       colnames(b)<-c('from', 'to')
        #       for (i in 1:length(features))
        #       {
        #         b[i,] <- c(features[i], target)
        #       }
        graph$arcs <- rbind(graph$arcs, c(features[i], target))
        graph <- set.graph.nodes.by.arcs(graph)
        plot(graph)
      }
    }
    else keep.going <- F




  }

  end.time <- Sys.time()
  time.taken <- end.time - start.time
  #print(paste("Time taken = ", time.taken, sep = ""))



  return(list(features, graph))
}
