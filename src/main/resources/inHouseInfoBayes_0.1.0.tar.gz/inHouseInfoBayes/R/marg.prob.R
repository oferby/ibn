marg.prob.old <- function(data, counts = NULL, margin = NULL)
{
  require("parallel")
  if(is.null(margin) == T) data.margin <- data else data.margin <- data[,margin]
  if (is.null(dim(data.margin)) == TRUE)
  {
    data.margin <- data.frame(data.margin)
  }
  else
  {
    data.margin <- as.data.frame(data.margin)
  }
  if(is.null(margin) == T)  colnames(data.margin) <- colnames(data) else colnames(data.margin) <- margin

  unique.data.margin <- unique(data.margin)

  if (is.null(counts) == FALSE)
  {
    count.cumulated.margin <- NULL
    pb <- txtProgressBar(min = 1, max = nrow(unique.data.margin), initial = 0, char = "=",
                   width = NA, title, label, style = 1, file = "")
    for (x in 1:nrow(unique.data.margin))
    {
      count.cumulated.margin[x] <- sum(counts[rows.in.a1.that.are.in.a2(data.margin, unique.data.margin[x,])])
      if(is.null(margin) == T)
      {
        getTxtProgressBar(pb)
        setTxtProgressBar(pb, x, title = NULL, label = NULL)
      }
    }

  }
  else
    count.cumulated.margin <- NULL
  return(list(unique.data.margin, count.cumulated.margin))
}
