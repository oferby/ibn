cond.entropy.from.counts <- function(data, counts, target = NULL, MC = 0, xi=NULL)
{
  unique.data <- marg.prob(data, counts, colnames(data), MC = 0)

  if (MC > 0)
  {
    # if (is.null(dim(xi)) == TRUE)
    # {
    #   xi <- as.matrix(xi)
    #   colnames(xi) <- colnames(data)
    # }

    response <- NULL
    unique.data.prob <- unique.data[[2]]/sum(unique.data[[2]])

    cumul.joint <- cumsum(unique.data.prob)

    conditioning <- marg.prob(unique.data[[1]], unique.data[[2]], colnames(data)[-which(colnames(data) %in% target)])

    if (length(conditioning[[1]]) > 0)
    {
      prob.conditioning <- conditioning[[2]]/sum(conditioning[[2]])
      cumul.conditioning <- cumsum(prob.conditioning)
    }

    for (iter in 1:MC)
    {
      #realization <- NULL
      #realization.prob <- 1
      #xi = runif(ncol(data), 0, 1)
      # for (field in 1:ncol(data))
      # {
      #   field.name <- colnames(data)[field]
      #   efi <- marg.prob(data, counts, field.name)
      #   cumul <- cumsum(efi[[2]]/sum(efi[[2]]))
      #   realization[field] <- efi[[1]][min(which(xi[iter,which(colnames(xi) %in% field.name)] <= cumul)),]
      #   realization.prob <- realization.prob*efi[[2]][which(efi[[1]] == realization[field])]
      # }


      realization.joint.idx <- min(which(xi[iter] <= cumul.joint))

      if (length(conditioning[[1]]) > 0)
      {
        realization.conditioning.idx <- min(which(xi[iter] <= cumul.conditioning))
        response[iter] <- log2(prob.conditioning[realization.conditioning.idx]) - log2(unique.data.prob[realization.joint.idx])
      }
      else
        response[iter] <- - log2(unique.data.prob[realization.joint.idx])





      # rows.of.realization <- rows.in.a1.that.are.in.a2(unique.data[[1]], realization.joint)
      # if (length(rows.of.realization) > 0)
      # {
      #   prob.realization <- unique.data.prob[rows.of.realization]
      #



        # rows.of.conditioning <- rows.in.a1.that.are.in.a2(unique.data[[1]][,-which(colnames(data) %in% target)], realization[-which(colnames(data) %in% target)])
        # if (length(rows.of.conditioning) > 0)
        # {
        #     prob.conditioning <- sum(unique.data.prob[rows.of.conditioning])
        #     if (sum(prob.realization, prob.conditioning) > 0)
        #     {
        #       response[iter] <- prob.realization/realization.prob*(log2(prob.conditioning) - log2(prob.realization))
        #     }
        #     else
        #       response[iter <- NA]
        # }
        # else
        #   response[iter] <- -log2(prob.realization)
      # }
      # else
      #   response[iter] <- NA
    }
    #print(response)
    return(mean(response, na.rm = TRUE))
  }
  else
  {
    if(is.null(target) == T) return(entropy.from.counts(unique.data[[2]]))

    if(length(colnames(data)[-which(colnames(data) %in% target)]) == 0)
    {
      return(entropy.from.counts(unique.data[[2]]))
    }

    yumba <- marg.prob(unique.data[[1]], unique.data[[2]], colnames(data)[-which(colnames(data) %in% target)])

    unique.data.yumba <- unique(yumba[[1]])
    if (nrow(unique.data.yumba) > 1) nRow <- nrow(unique.data.yumba)
    else nRow <- 1

    count.cumulated <- sapply(X = 1:nrow(unique.data.yumba), FUN = function(x) sum(unique.data[[2]][rows.in.a1.that.are.in.a2(unique.data[[1]][,names(data)[-which(names(data) %in% target)]], unique.data.yumba[x,])]))

    ent <- sapply(1:nRow, FUN = function(z) entropy.from.counts(unique.data[[2]][rows.in.a1.that.are.in.a2(unique.data[[1]][,names(data)[-which(names(data) %in% target)]], unique.data.yumba[z,])]))
    prob <- count.cumulated/sum(count.cumulated)
    return(ent%*%prob)
  }

}
