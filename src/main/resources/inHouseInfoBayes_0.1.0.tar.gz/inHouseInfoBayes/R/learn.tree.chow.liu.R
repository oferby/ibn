learn.tree.chow.liu <- function(data, counts)
{
  require("bnlearn")
  eg = empty.graph(colnames(data), 1)
  MIs <- matrix(nrow = dim(data)[2], ncol = dim(data)[2])
  i<-0
  for (tar in colnames(data))
  {
    i <- i + 1
    print(tar)
    fields <- colnames(data)
    MIs[i,] <- unlist(mclapply.hack(X = fields, function(var) mutual.information.from.counts(data[,c(tar,var)], counts, tar, about = var)))

  }

  var.1 <- NULL
  var.2 <- NULL


  sunto <- MIs
  while (max(sunto) > -1)
  {

    var.1 <- which.max(apply(sunto, 2, max))
    var.2 <- which.max(sapply(sunto[,var.1], max))

    parents <- collect.ancestors(eg, colnames(data)[var.2], direct.only = TRUE)
    if (length(parents) < 1)
      {

      descendants <- collect.descendants(eg, colnames(data)[var.2])

      fields <- colnames(data)[-which(colnames(data) %in% colnames(data)[var.2])]
      if (length(descendants) > 0) candidates <- fields[-which(fields %in% descendants)]
      else candidates <- fields

      if (colnames(data)[var.1] %in% candidates)
      {
        eg$arcs <- rbind(eg$arcs, c(colnames(data)[var.1], colnames(data)[var.2]))
      }
    }

    sunto[var.2, var.1] <- -1

    eg <- set.graph.nodes.by.arcs(eg)
  }
  return(eg)


}
