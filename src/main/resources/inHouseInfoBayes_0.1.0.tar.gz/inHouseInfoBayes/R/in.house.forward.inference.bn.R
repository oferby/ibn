in.house.forward.inference.bn <- function(bn, obs){
  require("bnlearn")
  assert(nnodes(bn) == dim(obs)[2])
  bn.vars <- attributes(bn$nodes)
  root.nodes<- root.nodes(bn)
  prob <- NULL
  for (var in colnames(obs))
  {
    parents <- collect.ancestors(bn, var, T)
    prob[var] <- bn$nodes[[var]]$prob[parents]

  }
    for (ch in children)
    {
      prob <- prob*bn$nodes$prob[ch, var]
    }


}
