collect.descendants <- function(graph, node, direct.only = FALSE)
{
  descendants <- graph$arcs[which(graph$arcs[,"from"] %in% node),"to"]
  if(direct.only == T) return(unique(descendants))
  
  if (length(descendants) > 0)
    for (desc in descendants)
    {
      descendants <- c(descendants, collect.descendants(graph, desc))
    }
return(unique(descendants))
}