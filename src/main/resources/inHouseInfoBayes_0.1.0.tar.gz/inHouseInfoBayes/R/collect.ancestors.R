collect.ancestors <- function(graph, node, direct.only = FALSE)
{
  ancestors <- graph$arcs[which(graph$arcs[,"to"] %in% node),"from"]
  if(direct.only == T) return(unique(ancestors))
  
  if (length(ancestors) > 0)
    for (anc in ancestors)
    {
      ancestors <- c(ancestors, collect.ancestors(graph, anc))
    }
return(unique(ancestors))
}